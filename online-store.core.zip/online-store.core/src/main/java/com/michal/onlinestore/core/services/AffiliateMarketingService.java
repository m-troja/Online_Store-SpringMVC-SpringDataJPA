package com.michal.onlinestore.core.services;

public interface AffiliateMarketingService {
	
	String generateUniquePartnerCode();

}
