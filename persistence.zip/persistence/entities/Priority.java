package com.michal.onlinestore.persistence.entities;

public enum Priority {
	LOW, MEDIUM, HIGH;
}
